<?php
// Config para sincronização (mantenha este arquivo fora de alcance público se possível)
$SYNC_SECRET = 'a7f9c4b6e8d1f2a3b4c5d6e7f8a9b0c1'; // chave gerada — troque se quiser
?>